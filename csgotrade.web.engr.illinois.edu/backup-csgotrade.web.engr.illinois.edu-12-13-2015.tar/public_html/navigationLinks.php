<?php
	$home = '<a href="/">home</a>';
	# $search = '<a href="/search.php">search</a>';
	$add = '<a href="/add.php">add</a>';
	$delete = '<a href="/delete.php">delete</a>';
	$update = '<a href="/update.php">update</a>';
	$addOffer ='<a href="/addOffer.php">Add offer</a>';
	$myOffers = '<a href="/myOffers.php">My offers</a>';
	
	
	$links = array($addOffer, $myOffers);
?>