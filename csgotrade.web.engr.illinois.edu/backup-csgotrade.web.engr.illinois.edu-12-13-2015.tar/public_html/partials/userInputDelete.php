<?php
	$queryDiv = '<div id="search-options">
	<form action="../delete.php?go" method="post">
		<ul>
			<li>Type:<input type="text" name="wpn-type"></li>
			<li>Skin:<input type="text" name="wpn-skin"></li>
			<li>Wear:<input type="text" name="wpn-wear"></li>
			<li><!-- Number of keys weapons costs -->Cost:<input type="text" name="wpn-cost"></li>
			<li><input type="submit" name="wpn-submit" value="Delete"></li>
		</ul>
	</form>
	</div>
	<br><br>';
?>