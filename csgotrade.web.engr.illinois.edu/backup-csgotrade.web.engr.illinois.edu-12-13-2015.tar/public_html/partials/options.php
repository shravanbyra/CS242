<?php
	$options = '<div id="user-options">
		<ul>
			<li><a href="../search.php">Search the DB</a></li>
			<li><a href="../add.php">Add to the DB</a></li>
			<li><a href="../update.php">Update the DB</a></li>
			<li><a href="../delete.php">Delete from the DB</a></li>
		</ul>
	</div>';	
?>