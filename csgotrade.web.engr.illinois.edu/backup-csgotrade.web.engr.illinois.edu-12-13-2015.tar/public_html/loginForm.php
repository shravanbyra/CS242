<?php
	$loginForm = 
		'<div id="register-form">
			<form name="login-form" class="user-form" action="/login.php" method="post">
				<input type="text" name="username" placeholder="username"/><br/>
				<input type="text" name="password" placeholder="password"/><br/>
				
				<input type="submit" name="submit" value="Login"/>
			</form>
		</div>';
	
	
?>