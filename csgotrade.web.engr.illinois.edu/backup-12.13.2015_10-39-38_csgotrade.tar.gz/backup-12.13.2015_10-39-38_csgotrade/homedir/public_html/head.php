<?php
$head = '
	<link rel="stylesheet" type="text/css" href="style/main.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
	<script src="script/main.js"></script>
	<script src="script/header.js"></script>
        <script src="script/delete.js"></script>
	';
?>